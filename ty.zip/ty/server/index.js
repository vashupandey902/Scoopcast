import express from 'express';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import cors from 'cors';
import path from 'path';

// Routes
import authRoutes from './routes/auth.js';
import podcastsRoutes from './routes/podcast.js';
import userRoutes from './routes/user.js';
import upload from './multerConfig.js'; // Import Multer configuration

const app = express();
dotenv.config();

/** Middlewares */
app.use(express.json({ limit: '1024mb' })); // Adjust the limit as needed
app.use(express.urlencoded({ limit: '1024mb', extended: true })); // For URL-encoded data

const corsConfig = {
    origin: 'http://localhost:3000', // or '*'
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type', 'Authorization'],
};
app.use(cors(corsConfig));

// Port configuration
const port = process.env.PORT || 8700;

// MongoDB connection
const connect = () => {
    mongoose.set('strictQuery', true);
    mongoose.connect(process.env.MONGO_URL).then(() => {
        console.log('MongoDB connected');
    }).catch((err) => {
        console.error(err);
    });
};

// File upload endpoint
app.post('/api/upload', upload.single('file'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ success: false, message: 'No file uploaded' });
    }
    const fileUrl = `${req.protocol}://${req.get('host')}/uploads/${req.file.filename}`;
    res.status(200).json({ success: true, fileUrl });
});

// Serve uploaded files statically
app.use('/uploads', express.static(path.resolve('uploads')));

/** Routes */
app.use("/api/auth", authRoutes);
app.use("/api/podcasts", podcastsRoutes);
app.use("/api/user", userRoutes);

/** Error handler middleware */
app.use((err, req, res, next) => {
    const status = err.status || 500;
    const message = err.message || "Something went wrong";
    return res.status(status).json({
        success: false,
        status,
        message,
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
    connect();
});
